#!/usr/bin/env python3
"""Configure the current Linux user's Codex; no administrator access needed."""
import argparse
import getpass
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import urllib.error
import urllib.request
from datetime import datetime

sys.path.insert(0, str(Path(__file__).resolve().parent / 'lib'))
import tomlkit


def configuration(text, folder, url, model):
    doc = tomlkit.parse(text)
    doc['model'] = model
    doc['model_provider'] = 'cpa'
    providers = doc.setdefault('model_providers', tomlkit.table())
    provider = tomlkit.table()
    provider.update(name='Company GPT', base_url=url, wire_api='responses',
                    supports_websockets=False)
    auth = tomlkit.table()
    auth['command'] = '/usr/bin/cat'
    auth['args'] = [str(folder / 'cpa-key')]
    provider['auth'] = auth
    providers['cpa'] = provider
    result = tomlkit.dumps(doc)
    tomlkit.parse(result)
    return result


def write_private(path, data):
    fd, temporary = tempfile.mkstemp(prefix='.cpa-setup-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(data)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def check(url, model, key):
    # Never route the internal API through the user's internet proxy.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(url + '/responses', data=json.dumps({
        'model': model, 'input': 'Reply with OK only.'
    }).encode(), headers={'Authorization': 'Bearer ' + key,
                         'Content-Type': 'application/json'})
    try:
        with opener.open(request, timeout=120) as response:
            data = json.load(response)
        if data.get('error') or data.get('status') != 'completed':
            raise ValueError('模型未完成请求，请管理员检查上游状态。')
        if not any(c.get('text') for item in data.get('output', [])
                   for c in item.get('content', [])):
            raise ValueError('接口未返回文本，请联系管理员。')
    except urllib.error.HTTPError as error:
        hints = {401: 'key 无效或模型未授权', 403: '权限不足',
                 429: '请求频率或额度达到上限', 503: '上游账号暂不可用'}
        raise ValueError('测试失败 HTTP %s：%s。未改写配置。' %
                         (error.code, hints.get(error.code, '请管理员检查接口日志'))) from None
    except (urllib.error.URLError, TimeoutError):
        raise ValueError('连接失败或超时。请检查公司网络，并联系管理员。未改写配置。') from None


def main():
    parser = argparse.ArgumentParser(description='公司 Codex 一键配置（Linux / Remote SSH）')
    parser.add_argument('--url', default='http://10.4.6.227:18318/v1')
    parser.add_argument('--model', default='gpt-5.6-sol')
    args = parser.parse_args()
    if sys.platform != 'linux' or os.geteuid() == 0:
        raise ValueError('请在自己的 Linux 账号或 VS Code 远程终端运行，不要使用 sudo。')
    url = args.url.rstrip('/')
    if not url.startswith(('http://', 'https://')):
        raise ValueError('API 地址必须以 http:// 或 https:// 开头。')
    folder = Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))).expanduser().absolute()
    if folder.is_symlink():
        raise ValueError('配置目录为符号链接，请管理员协助检查。')
    config, secret = folder / 'config.toml', folder / 'cpa-key'
    for path in (config, secret):
        if path.is_symlink():
            raise ValueError('配置或密钥文件为符号链接，请管理员协助检查。')
    original = config.read_text(encoding='utf-8') if config.exists() else ''
    updated = configuration(original, folder, url, args.model)
    print('用户：' + getpass.getuser())
    print('配置目录：' + str(folder))
    print('API：' + url + '；模型：' + args.model)
    print('将修改默认模型及 cpa 提供商，保留其他设置；旧配置和已有密钥会备份。')
    if input('确认为你自己的账号并开始配置？[y/N] ').strip().lower() != 'y':
        print('已取消，未改动任何配置。')
        return
    key = getpass.getpass('粘贴你自己的 CPA API key（输入不显示）：').strip()
    if not key or any(c.isspace() for c in key):
        raise ValueError('key 为空或含空白字符，请重新复制。')
    print('正在测试真实模型调用，消耗一次少量请求，最长等待 120 秒……')
    check(url, args.model, key)
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backups = []
    for path in (config, secret):
        if path.exists():
            backup = folder / (path.name + '.backup.' + stamp)
            write_private(backup, path.read_text(encoding='utf-8'))
            backups.append(str(backup))
    try:
        write_private(secret, key)
        write_private(config, updated)
    except Exception:
        # Restore the previous key if the config write fails.
        key_backup = folder / ('cpa-key.backup.' + stamp)
        if key_backup.exists():
            write_private(secret, key_backup.read_text(encoding='utf-8'))
        elif secret.exists():
            secret.unlink()
        raise
    print('成功：模型调用通过，密钥和配置已保存。')
    for backup in backups:
        print('备份：' + backup)
    print('下一步：VS Code 按 Ctrl+Shift+P，运行 Developer: Reload Window。')
    print('打开 Codex，新建对话即可使用；无需登录 ChatGPT 或设置环境变量。')


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, tomlkit.exceptions.ParseError) as error:
        print('未完成：' + str(error), file=sys.stderr)
        sys.exit(1)
